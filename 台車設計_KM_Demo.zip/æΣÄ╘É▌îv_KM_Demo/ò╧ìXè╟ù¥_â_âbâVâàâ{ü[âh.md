---
type: dashboard
tags: [dashboard, dataview]
---

# 変更管理ダッシュボード

このノートはDataviewプラグインによる自動集計を行います。
Obsidianで開くと以下のクエリが実行され、波及漏れを即座に発見できます。

---

## 要確認ノード一覧（自動集計）

```dataview
TABLE status, affected_by
FROM "台車設計_KM_Demo"
WHERE contains(tags, "要確認")
SORT status ASC
```

---

## ECR-001の波及先マップ（自動集計）

```dataview
TABLE type, status, date(file.mtime, "yyyy-MM-dd") AS 最終更新
FROM "台車設計_KM_Demo"
WHERE contains(affected_by, "ECR-001_車軸穴公差変更")
SORT type ASC
```

---

## 全ノード ステータス一覧

```dataview
TABLE type, status
FROM "台車設計_KM_Demo"
WHERE type != "dashboard" AND type != "index"
SORT type ASC
```

---

## ダッシュボードの使い方

1. 上の「要確認ノード一覧」に `JIG-001` と `QC-001` が並ぶ
2. どちらも `affected_by: ECR-001` と表示される
3. tree構造ではこの横断的な一覧は手動で作るしかなかった

> Dataviewはノートの frontmatter（メタデータ）を自動でクエリする。
> 「どのノードがECR-001の影響を受けているか」をSQLライクに問い合わせられる。
