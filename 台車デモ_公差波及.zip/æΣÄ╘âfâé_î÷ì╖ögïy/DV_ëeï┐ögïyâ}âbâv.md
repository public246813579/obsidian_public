---
tags: [demo/dataview]
---
# 影響波及マップ (Dataview)

[[ECR-042_車軸公差変更]] を起点に、タグとフロントマターで機械的に影響範囲を抽出する。
*Dataviewプラグインが有効である必要あり。*

## 組立に影響するノート
```dataview
TABLE file.tags AS タグ, 文書番号, 改訂
FROM "台車デモ_公差波及"
WHERE contains(file.tags, "#影響/組立")
```

## 検査に影響するノート
```dataview
TABLE file.tags AS タグ, 治具番号, 基準公差
FROM "台車デモ_公差波及"
WHERE contains(file.tags, "#影響/検査")
```

## h7基準で作られた資産（ECR-042後は要見直し）
```dataview
LIST
FROM "台車デモ_公差波及"
WHERE 基準公差 = "h7" OR 旧公差 = "h7" OR 公差 = "h7"
```

## 部品一覧
```dataview
TABLE 部品番号, 材質
FROM "台車デモ_公差波及"
WHERE contains(file.tags, "#部品")
```

## デモ観点
tree構造（フォルダ）では `影響/組立` `影響/検査` `公差/h7` といった横断軸で束ねることは不可能。タグ+Dataviewは設計変更のインパクト分析を**常時最新**で提供する。
