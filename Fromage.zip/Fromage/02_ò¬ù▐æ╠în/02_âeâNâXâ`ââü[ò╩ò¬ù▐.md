# テクスチャー別分類 — 6カテゴリ体系

Tags: #fromage #分類 #テクスチャー
関連: [[Fromage/02_分類体系/01_AOPとIGP制度]] | [[Fromage/02_分類体系/03_乳種別分類]]

---

## フランス式6分類体系

フランスのチーズ専門教育では、テクスチャー（水分含量・外皮・製造法）で6大カテゴリに分類する。

---

## カテゴリ1: フレッシュチーズ（Fromages frais）

**水分含量**: 60〜80%
**熟成**: なし（または数日）
**特徴**: 白く軟質・酸味・クリーミー

| チーズ名 | 産地 | 特記事項 |
|---|---|---|
| Fromage blanc | 汎フランス | 低脂肪〜クリーミーまで幅広い |
| Faisselle | 汎フランス | 穴あき型で成形 |
| Brousse | プロヴァンス | 羊または山羊乳 |
| Brocciu | コルシカ | AOP・乳清（ホエー）使用 |
| Chèvre frais | ロワール他 | 山羊乳フレッシュ |

---

## カテゴリ2: 白カビチーズ（Pâte molle à croûte fleurie）

**水分含量**: 50〜60%
**熟成**: 2〜8週間
**外皮**: Penicillium camembertiによる白い毛状

| チーズ名 | AOP | 特徴 |
|---|---|---|
| Camembert de Normandie | あり | 生乳必須・Normande種・10.5〜11cm |
| Brie de Meaux | あり | 大型・複雑な風味・「チーズの王」 |
| Brie de Melun | あり | Brie de Meauxより強く複雑 |
| Coulommiers | なし | Briより小型・マイルド |
| Chaource | あり | クリーミー・かすかな酸味 |
| Neufchâtel | あり | ハート型・1200年の歴史 |

---

## カテゴリ3: ウォッシュ外皮チーズ（Pâte molle à croûte lavée）

**水分含量**: 50〜60%
**熟成**: 4〜12週間
**外皮**: Brevibacterium linensによるオレンジ〜赤褐色
**香気**: 最強烈カテゴリ（アンモニア・硫黄・酪酸）

| チーズ名 | 洗浄液 | 強度 |
|---|---|---|
| Époisses | Marc de Bourgogne | 最強（Napoleon好物と伝説） |
| Munster | 塩水・地酒 | 強 |
| Livarot | 塩水 | 強 |
| Pont-l'Évêque | 塩水 | 中 |
| Langres | Champagne・Marc | 強（上部の凹みにChampagneを注ぐ食べ方） |
| Maroilles | 塩水 | 強 |
| Reblochon | 塩水 | 中（比較的穏やか） |

---

## カテゴリ4: 青カビチーズ（Pâte persillée）

**水分含量**: 40〜50%
**熟成**: 2〜6ヶ月
**特徴**: Penicillium roquefortiによる内部青緑カビ・針刺し（Piquage）必須

| チーズ名 | 乳種 | 特徴 |
|---|---|---|
| Roquefort | 羊 | AOP・洞窟熟成・最高位青カビ |
| Bleu d'Auvergne | 牛 | AOP・強くクリーミー |
| Fourme d'Ambert | 牛 | AOP・穏やか・初心者向き |
| Bleu de Gex | 牛 | AOP・フランシュ＝コンテ |
| Gorgonzola | 牛 | イタリア・DOP |
| Stilton | 牛 | 英国・PDO |

---

## カテゴリ5: セミハードチーズ（Pâte pressée non cuite）

**水分含量**: 35〜45%
**熟成**: 1〜6ヶ月
**製法**: カードを押圧（プレス）するが加熱しない

| チーズ名 | AOP | 産地 |
|---|---|---|
| Saint-Nectaire | あり | オーヴェルニュ |
| Ossau-Iraty | あり | バスク・ピレネー |
| Cantal jeune/entre-deux | あり | オーヴェルニュ |
| Tomme de Savoie | なし | アルプス |
| Abondance | あり | アルプス |
| Mimolette | なし | フランドル（Acarus cheeseiダニ外皮） |

---

## カテゴリ6: ハードチーズ（Pâte pressée cuite）

**水分含量**: 25〜35%（以下）
**熟成**: 6ヶ月〜数年
**製法**: カードを高温加熱後にプレス。長期熟成に対応

| チーズ名 | 熟成期間 | 特徴 |
|---|---|---|
| Comté | 4〜36ヶ月（最長） | 複雑な風味階層・花・ナッツ・フルーツ |
| Beaufort | 6ヶ月〜 | 凹型外縁・アルプスの宝石 |
| Emmental | 4ヶ月〜 | 穴（目）・マイルド |
| Gruyère（スイス） | 5〜12ヶ月 | 穴なし・より強い風味 |
| Parmigiano Reggiano | 12〜36ヶ月 | イタリア・旨味の極致 |

---

## 水分含量と熟成期間の関係

水分含量が低いほど:
- 長期熟成が可能（水分活性の低下が腐敗を防ぐ）
- 風味が凝縮される
- テクスチャーが硬く結晶化しやすい（チロシン結晶）

---

## 次のステップ
- [[Fromage/02_分類体系/03_乳種別分類]]
- [[Fromage/02_分類体系/04_カビ外皮タイプ別]]
- [[Fromage/03_主要チーズ図鑑/Comte]]
