# AOPとIGP制度 — フランスの原産地保護制度

Tags: #fromage #分類 #AOP #法規制
関連: [[Fromage/00_INDEX]] | [[Fromage/02_分類体系/02_テクスチャー別分類]]

---

## 制度の階層構造

EU制度（上位）
├── AOP（Appellation d'Origine Protégée）— 最高位
├── IGP（Indication Géographique Protégée）— 中位
└── STG（Spécialité Traditionnelle Garantie）— 製法保護

フランス国内制度（AOPと同義）
└── AOC（Appellation d'Origine Contrôlée）— フランス国内呼称

---

## AOPの要件

AOPを名乗るには以下の3要素が産地と結びついていること:

1. **生産地（Aire géographique）**: 指定地域内での原料生産
2. **製造（Transformation）**: 指定地域内での製造・熟成
3. **特性（Qualité/Caractéristiques）**: 地域の地理的・人的要因に由来する特性

### AOP認定の意味
- 特定地域外でのブランド名使用を法的に禁止
- 例: Champagneと同じ構造 — Camembert de Normandieはノルマンディー外で作れない

---

## フランスのAOP認定チーズ一覧（主要45品種）

### ノルマンディー地方
| チーズ | 特徴 | 乳種 |
|---|---|---|
| Camembert de Normandie | 白カビ・生乳必須 | 牛（Normande種） |
| Livarot | ウォッシュ・強烈な香り | 牛 |
| Pont-l'Évêque | 正方形・ウォッシュ | 牛 |
| Neufchâtel | 白カビ・ハート型が有名 | 牛 |

### ブルゴーニュ・シャンパーニュ地方
| チーズ | 特徴 | 乳種 |
|---|---|---|
| Époisses | ウォッシュ・マール洗い | 牛 |
| Langres | ウォッシュ・凹型上部 | 牛 |
| Chaource | 白カビ・クリーミー | 牛 |

### フランシュ＝コンテ・アルプス地方
| チーズ | 特徴 | 乳種 |
|---|---|---|
| Comté | ハード・複雑熟成 | 牛（Montbéliarde/Simmental） |
| Beaufort | ハード・凹型外縁 | 牛 |
| Emmental de Savoie | 穴あきハード | 牛 |
| Abondance | セミハード | 牛 |
| Reblochon | 白外皮・マイルド | 牛 |
| Vacherin Mont d'Or | 季節限定・超軟質 | 牛 |

### ロワール渓谷（山羊乳の聖地）
| チーズ | 特徴 | 乳種 |
|---|---|---|
| Crottin de Chavignol | 小円筒形・熟成で硬化 | 山羊 |
| Sainte-Maure de Touraine | 藁刺し・長円筒 | 山羊 |
| Valençay | ピラミッド型・灰粉 | 山羊 |
| Selles-sur-Cher | 円盤型・灰粉 | 山羊 |
| Pouligny-Saint-Pierre | 四角錐 | 山羊 |

### オーヴェルニュ地方
| チーズ | 特徴 | 乳種 |
|---|---|---|
| Cantal | 大型ハード・3段階熟成 | 牛 |
| Salers | Cantalの上位版・季節限定 | 牛（Salers種） |
| Saint-Nectaire | 天然外皮・セミソフト | 牛 |
| Fourme d'Ambert | 青カビ・穏やか | 牛 |
| Bleu d'Auvergne | 青カビ・強い風味 | 牛 |

### 南西・バスク地方
| チーズ | 特徴 | 乳種 |
|---|---|---|
| Ossau-Iraty | セミハード・ナッツ風味 | 羊（Manech/Basco-béarnaise） |
| Roquefort | 青カビの王・洞窟熟成 | 羊（Lacaune種） |

### イル＝ド＝フランス
| チーズ | 特徴 | 乳種 |
|---|---|---|
| Brie de Meaux | 白カビ・チーズの王 | 牛 |
| Brie de Melun | Briより強い風味 | 牛 |
| Coulommiers | Briより小型 | 牛 |

---

## Cantalの3段階熟成モデル（例）

AOPによっては熟成段階で呼称が変わるケースがある:

| 段階 | 熟成期間 | 呼称 | 特徴 |
|---|---|---|---|
| 1 | 1〜2ヶ月未満 | Cantal jeune | マイルド・弾力あり |
| 2 | 2〜6ヶ月 | Cantal entre-deux | バランス型 |
| 3 | 6ヶ月以上 | Cantal vieux | ドライ・強い風味 |

---

## IGPとの違い

| 基準 | AOP | IGP |
|---|---|---|
| 原料の産地 | 指定地域内必須 | 指定地域内が推奨（一部例外可） |
| 製造地 | 指定地域内必須 | 指定地域内必須 |
| 制度の厳格さ | 高い | 中程度 |
| 例 | Roquefort, Comté | Emmental français est-central |

---

## 次のステップ
- [[Fromage/02_分類体系/02_テクスチャー別分類]]
- [[Fromage/03_主要チーズ図鑑/Roquefort]]
