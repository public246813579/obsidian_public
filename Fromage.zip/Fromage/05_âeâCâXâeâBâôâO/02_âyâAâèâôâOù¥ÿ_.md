# ペアリング理論

Tags: #fromage #テイスティング #ペアリング #ワイン
関連: [[Fromage/05_テイスティング/01_感覚評価法]] | [[Fromage/05_テイスティング/03_プレゼンテーション技術]]

---

## ペアリングの基本原則

チーズと飲食物のペアリングには3つの基本アプローチがある:

1. **調和（Accord）**: 似た風味・テクスチャーを合わせる
2. **対比（Contraste）**: 対極の要素で互いを引き立てる
3. **テロワール（Terroir）**: 同じ産地の組み合わせ（地域の必然性）

---

## チーズ × ワインのペアリング

### 基本ルールと例外

**クラシックな格言「白ワインとチーズ」は正しいか?**

結論: **白ワインの方が安全だが、赤ワインも成立する組み合わせは存在する。**

理由:
- 赤ワインのタンニンが乳脂肪のカゼインと結合 → 金属臭・収斂感
- タンニンが少ない赤ワイン（Pinot Noir、Gamay）は問題が小さい
- 塩味の強いチーズ（Roquefort等）は甘口ワインと対比効果

---

## カテゴリ別ペアリングマトリックス

### フレッシュチーズ
| チーズ | 推奨ワイン | 理由 |
|---|---|---|
| Chèvre frais | Sancerre（Sauvignon Blanc）| 産地一致・酸味共鳴 |
| Fromage blanc | Crémant d'Alsace | 軽さのマッチング |
| Brocciu | Muscat d'Alsace（甘口）| 対比・甘み×酸味 |

### 白カビ系
| チーズ | 推奨ワイン | 理由 |
|---|---|---|
| Camembert de Normandie | Cidre Brut Normand | 産地一致・発泡でリセット |
| Camembert de Normandie | Champagne Blanc de Blancs | 炭酸がクリームを洗い流す |
| Brie de Meaux | Pinot Noir（Burgundy） | 軽い赤・クラシック |
| Brie de Meaux | Champagne | 古典的フランス式 |
| Chaource | Champagne地方の白 | 産地一致 |

### ウォッシュ系
| チーズ | 推奨ワイン | 理由 |
|---|---|---|
| Époisses | Bourgogne Blanc（Meursault）| 白の豊かさが強さに対抗 |
| Époisses | Gewurztraminer | 花・スパイスが匂いを昇華 |
| Munster | Gewurztraminer d'Alsace | 産地一致・古典的ペアリング |
| Livarot | Cidre du Pays d'Auge | 産地一致 |

### 青カビ系
| チーズ | 推奨ワイン | 理由 |
|---|---|---|
| Roquefort | Sauternes（特にChâteau d'Yquem）| 対比の王道（塩×甘）|
| Roquefort | Banyuls、Maury | 南仏の甘口赤・タンニン少 |
| Bleu d'Auvergne | Monbazillac | 甘口白・対比 |
| Fourme d'Ambert | Côtes du Rhône Blanc | 穏やかなペアリング |

### セミハード系
| チーズ | 推奨ワイン | 理由 |
|---|---|---|
| Saint-Nectaire | Pinot Noir（Auvergne）| 産地一致 |
| Ossau-Iraty | Jurançon（甘口/辛口）| バスク産地一致 |
| Ossau-Iraty | Irouléguy（バスクの赤）| 産地一致 |

### ハード系
| チーズ | 推奨ワイン | 理由 |
|---|---|---|
| Comté | Vin Jaune（Jura）| 最高の産地一致ペアリング |
| Comté | Chardonnay（Burgundy）| ナッツ×バター共鳴 |
| Beaufort | Apremont（Savoie）| 産地一致 |
| Parmesan | Lambrusco Secco | イタリア産地一致 |

---

## ワイン以外のペアリング

### パン
| パンの種類 | 合うチーズ | 理由 |
|---|---|---|
| バゲット（プレーン）| 全種（汎用）| チーズを引き立て主張しない |
| くるみパン（Pain aux noix）| Comté, Brie | ナッツ風味共鳴 |
| ライ麦パン | Chèvre, 青カビ系 | 酸味・素朴さのマッチング |
| フィグブレッド | Roquefort, Époisses | 甘みが強さを和らげる |
| クラッカー（無塩）| 全種 | 繊細なチーズに向く |

### 蜂蜜（Miel）

蜂蜜との対比ペアリングはフランスの古典:

| 蜂蜜の種類 | 合うチーズ |
|---|---|
| アカシア蜜（淡・繊細）| Chèvre frais、Brie |
| 栗蜜（苦い・強い）| Comté vieux、Époisses |
| ラベンダー蜜 | Chèvre、フレッシュ系 |
| トリュフ蜂蜜 | Brie de Meaux |
| 百花蜜 | Roquefort（対比）|

### ドライフルーツ・ナッツ
- 無花果（Figue sèche）: Roquefort、Brie
- レーズン（Raisin）: Comté、Cantal vieux
- クルミ（Noix）: Bleu系、Comté
- アーモンド: Chèvre、セミハード全般
- デーツ（Datte）: Époisses、ウォッシュ系

### ジャム・コンフィチュール
- 洋梨コンフィチュール: Roquefort
- チェリーコンフィチュール: Manchego（スペイン）
- オニオンコンフィチュール: Comté vieux、Brie

---

## ペアリングの失敗パターン（避けるべき組み合わせ）

| チーズ | 避けるべき | 理由 |
|---|---|---|
| 全般 | 重いCabernet Sauvignon | タンニンが金属臭を生む |
| Époisses | 赤ワイン（ほぼ全般）| 硫黄×タンニン = 不快 |
| Chèvre frais | 樽Chardonnay | バターがシェヴル感を殺す |
| 青カビ系 | 辛口赤（Bordeaux等）| 苦味×タンニン = 過剰な苦 |

---

## チーズコース（Plateau de fromages）の構成原則

フランス式チーズコースの組み合わせ方:

1. **多様性の原則**: テクスチャー・乳種・産地を分散
2. **最低3〜5種類**: 少なすぎると比較・発見がない
3. **配置**: プレート上で強いものを外側、デリケートなものを中心
4. **温度管理**: 全て室温に戻す
5. **食べる順序**: マイルドから強いものへ（フレッシュ→白カビ→セミハード→ハード→青カビ→ウォッシュ）

---

## 次のステップ
- [[Fromage/05_テイスティング/03_プレゼンテーション技術]]
- [[Fromage/07_実践ログ/テイスティング記録テンプレート]]
